
public enum ServiceStatusEnum {
		  OK,  INFORMATION_MISSED,  INFORMATION_INVALID,  CLIENT_EXISTED;
}
