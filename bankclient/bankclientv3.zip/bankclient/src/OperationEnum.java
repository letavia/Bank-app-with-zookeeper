

import java.io.Serializable;

public enum OperationEnum
  implements Serializable
{
  CREATE_CLIENT,  READ_CLIENT,  UPDATE_CLIENT,  DELETE_CLIENT,  CREATE_BANK;
}
