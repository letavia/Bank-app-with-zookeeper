
public interface Service <BankClient>{
	public ServiceStatus createAccount(BankClient client);
	public ServiceStatus updateAccount(BankClient client);
	public BankClient readAccount(String name);
	public BankClient readAccount(int accNumber);
	public ServiceStatus deleteAccount(int accNumber);
}
