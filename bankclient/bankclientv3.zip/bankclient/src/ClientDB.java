

import java.util.HashMap;

public class ClientDB implements java.io.Serializable
{
  private static final long serialVersionUID = 1L;
  private HashMap<Integer, Client> clientDB;

  public ClientDB(ClientDB clientDB)
  {
    this.clientDB = clientDB.getClientDB();
  }

  public ClientDB() {
    clientDB = new HashMap();
  }

  public HashMap<Integer, Client> getClientDB() {
    return clientDB;
  }
  
  public boolean createClient(Client client) {
    if (clientDB.containsKey(Integer.valueOf(client.getAccountNumber()))) {
      return false;
    }
    clientDB.put(Integer.valueOf(client.getAccountNumber()), client);
    return true;
  }

  public Client readClient(Integer accountNumber)
  {
    if (clientDB.containsKey(accountNumber)) {
      return (Client)clientDB.get(accountNumber);
    }
    return null;
  }

  public boolean updateClient(int accNumber, int balance)
  {
    if (clientDB.containsKey(Integer.valueOf(accNumber))) {
      Client client = (Client)clientDB.get(Integer.valueOf(accNumber));
      client.setBalance(balance);
      clientDB.put(Integer.valueOf(client.getAccountNumber()), client);
      return true;
    }
    return false;
  }

  public boolean deleteClient(Integer accountNumber)
  {
    if (clientDB.containsKey(accountNumber)) {
      clientDB.remove(accountNumber);
      return true;
    }
    return false;
  }

  public boolean createBank(ClientDB clientDB)
  {
    System.out.println("createBank");
    this.clientDB = clientDB.getClientDB();
    System.out.println(clientDB.toString());
    return true;
  }

  public String toString() {
    String aux = new String();

    for (java.util.Map.Entry<Integer, Client> entry : clientDB.entrySet()) {
      aux = aux + ((Client)entry.getValue()).toString() + "\n";
    }
    return aux;
  }
}
