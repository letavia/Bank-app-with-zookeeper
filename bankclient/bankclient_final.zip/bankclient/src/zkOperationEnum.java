

import java.io.Serializable;

public enum zkOperationEnum
  implements Serializable
{
  CREATE_CLIENT,  READ_CLIENT,  UPDATE_CLIENT,  DELETE_CLIENT,  CLIENT_DB, CREATE_BANK;
}
