import java.io.PrintStream;
import java.util.HashMap;

import org.apache.zookeeper.ZooKeeper;

public class zkBank {

  public zkClientDB clientDB;
  public zkSendMessagesBank sendMessages;
  HashMap<Integer, zkClient> clientDBHM;
  boolean what;

  public zkBank() {
    clientDB = new zkClientDB();
    sendMessages = new zkSendMessagesBank();
  }

  public void close(ZooKeeper zk) throws InterruptedException {
	  zk.close();
  }

  //{
  //  Object dhtbdObj = null;
  //  try
  //  {
  //    dhtbdObj = org.jgroups.util.Util.objectFromByteBuffer(msg.getBuffer());
  //  } catch (Exception e) {
  //    System.out.println(e.getStackTrace());
  //    System.out.println(e.toString());
  //    System.out.println("Exception objectFromByteBuffer");
  //  }
  //  OperationBank operation = (OperationBank)dhtbdObj;
  //  handleReceiverMsg(operation);
  //}

  public synchronized void handleReceiverMsg(zkOperationBank operation)
  {
    switch (operation.getOperation()) {
    case CREATE_CLIENT:
      what = clientDB.createClient(operation.getClient());
      System.out.println("ClientDB from zkBank:" + clientDB.clientDBHM.toString() + what);
      break;
    case READ_CLIENT:
      clientDB.readClient(operation.getAccountNumber());
      break;
    case UPDATE_CLIENT:
      clientDB.updateClient(operation.getClient().getAccountNumber(),
      operation.getClient().getBalance());
      break;
    case DELETE_CLIENT:
      clientDB.deleteClient(operation.getAccountNumber());
      break;
    case CLIENT_DB:       
      clientDB.readClientDB(operation.getClientDB());
    }
    System.out.println(operation.getOperation() + " COMPLETE");
  }

  public void createClient(ZooKeeper zk, zkClient client)
  {
    sendMessages.sendAdd(zk, client);
    //return clientDB.createClient(client);
    
  }

  public zkClient readClient(Integer accountNumber)
  {
    return clientDB.readClient(accountNumber);
  }

  public boolean updateClient(ZooKeeper zk, int accNumber, int balance) {
    boolean isCorrect = clientDB.updateClient(accNumber, balance);
    sendMessages.sendUpdate(zk, clientDB.readClient(Integer.valueOf(accNumber)));
    return isCorrect;
  }

  public boolean deleteClient(ZooKeeper zk, Integer accountNumber) {
    sendMessages.sendDelete(zk, accountNumber);
    return clientDB.deleteClient(accountNumber);
  }
  
  public boolean readClientDB() {
    return clientDB.readClientDB(clientDB);
  }

  public String toString() {
    String string = null;
    string = "          Bank Java     \n------------------------\n";

    string = clientDB.getClientDB().toString();
    return string;
  }
}
