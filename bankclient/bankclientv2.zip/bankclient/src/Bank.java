
import java.io.PrintStream;
import org.jgroups.Address;
import org.jgroups.JChannel;
import org.jgroups.Message;
import org.jgroups.View;
//import zookeeper

public class Bank extends org.jgroups.ReceiverAdapter
{
  private JChannel channel;
  private ClientDB clientDB;
  private SendMessagesBank sendMessages;
  private boolean isLeader = false;
  private View previousView = null;


  public Bank(String cluster)
  {
    clientDB = new ClientDB();
    try {
      channel = new JChannel().setReceiver(this);
      channel.connect(cluster);
    } catch (Exception e) {
      System.out.println("Error to create the JGroups channel");
    }
    sendMessages = new SendMessagesBank(channel);

    previousView = channel.getView();
  }

  public boolean isLeader()
  {
    return isLeader;
  }

  public void close() {
    channel.close();
  }


  public void viewAccepted(View newView)
  {
    try
    {
      Address address = null;
      if (((Address)newView.getMembers().get(0)).equals(channel.address())) { isLeader = true;
      }

      if ((isLeader) && (previousView != null) && (previousView.size() < newView.size()))
      {



        address = (Address)newView.getMembers().get(newView.size() - 1);
        sendMessages.sendCreateBank(address, clientDB);
        System.out.println("SendCreateBank");
      }
    } catch (Exception e) {
      System.out.println("Unexpected exception in viewAccepted");
    }
    previousView = newView;
  }


  public void receive(Message msg)
  {
    Object dhtbdObj = null;
    try
    {
      dhtbdObj = org.jgroups.util.Util.objectFromByteBuffer(msg.getBuffer());
    } catch (Exception e) {
      System.out.println(e.getStackTrace());
      System.out.println(e.toString());
      System.out.println("Exception objectFromByteBuffer");
    }
    OperationBank operation = (OperationBank)dhtbdObj;
    handleReceiverMsg(operation);
  }

  private synchronized void handleReceiverMsg(OperationBank operation)
  {
    switch (operation.getOperation()) {
    case CREATE_BANK:
      clientDB.createClient(operation.getClient());
      break;
    case CREATE_CLIENT:
      clientDB.readClient(operation.getAccountNumber());
      break;
    case DELETE_CLIENT:
      clientDB.updateClient(operation.getClient().getAccountNumber(),
        operation.getClient().getBalance());
      break;
    case READ_CLIENT:
      clientDB.deleteClient(operation.getAccountNumber());
      break;
    case UPDATE_CLIENT:
      System.out.println("Received CREATE_BANK");


      clientDB.createBank(operation.getClientDB());
    }
  }

  public boolean createClient(Client client)
  {
    sendMessages.sendAdd(null, client);
    return clientDB.createClient(client);
  }


  public Client readClient(Integer accountNumber)
  {
    return clientDB.readClient(accountNumber);
  }

  public boolean updateClient(int accNumber, int balance) {
    boolean isCorrect = clientDB.updateClient(accNumber, balance);
    sendMessages.sendUpdate(null, clientDB.readClient(Integer.valueOf(accNumber)));
    return isCorrect;
  }

  public boolean deleteClient(Integer accountNumber) {
    sendMessages.sendDelete(null, accountNumber);
    return clientDB.deleteClient(accountNumber);
  }

  public String toString() {
    String string = null;
    string = "          Bank Java     \n------------------------\n";

    string = clientDB.toString();
    return string;
  }
}
