

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;
import java.util.concurrent.locks.Lock;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;


public class zkMember_aa2 implements Watcher{
	private static final int SESSION_TIMEOUT = 5000;

	private static String rootMembers = "/members";
	private static String aMember = "/member-";
	private static String rootBarrier = "/b1";
	private String myId;
	private String leader="";
	private int sizeBarrier = 1;
	Random rand = new Random();

	private int nBarriers = 0;

	static Integer mutexBarrier = -1;
	static Integer mutexMember = -1;

	List<String> listBarriers = null;
	List<String> listMembers  = null;


	// This is static. A list of zookeeper can be provided for decide where to connect
	String[] hosts = {"127.0.0.1:2181", "127.0.0.1:2182", "127.0.0.1:2183"};

	static ZooKeeper zk;


	public zkMember_aa2 () {
		// Select a random zookeeper server
		Random rand = new Random();
		int i = rand.nextInt(hosts.length);
		// Create a session and wait until it is created.
		// When is created, the watcher is notified
		try {
			if (zk == null) {
				zk = new ZooKeeper(hosts[i], SESSION_TIMEOUT, this);
				// We initialize the mutex Integer just after creating ZK.
				System.out.println(i);
				try {
					// Wait for creating the session. Use the object lock
					synchronized(mutex) {
						mutex.wait();
					}
					zk.exists("/", false);
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		} catch (Exception e) {
			System.out.println("Exception in constructor");
		}

		// Add the process to the members in zookeeper

		if (zk != null) {
			// Create a folder for members and include this process/server
			try {
				// Create a folder, if it is not created
				String response = new String();
				Stat s = zk.exists(rootMembers, false);
				if (s == null) {
					// Created the znode, if it is not created.
					response = zk.create(rootMembers, new byte[0],
							Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
					System.out.println(response);
				}

				// Create a znode for registering as member and get my id
				myId = zk.create(rootMembers + aMember, new byte[0],
						Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);
				myId = myId.replace(rootMembers + "/", "");
				// false. Debe esperar a arrancar el barrir
				listMembers = zk.getChildren(rootMembers,  false, s);
				System.out.println("Created znode nember id:"+ myId );
				printListMembers(listMembers);


			} catch (KeeperException e) {
				System.out.println("The session with Zookeeper failes. Closing");
				return;
			} catch (InterruptedException e) {
				System.out.println("InterruptedException raised");
			}

			if (zk != null) {
				createBarrier();
				leaderElection(listMembers);
			}
		}

	}


	static Integer mutex = -1;
	//public static Watcher  watcherBarrier = new Watcher() {
	public void process (WatchedEvent event) {

		Stat s = null;

		System.out.println("------------------Watcher Process------------------");
		System.out.println("Process: " + event.getType() + ", " + event.getPath());
		try {
			if (event.getPath() == null) {
				//if (event.getState() == Watcher.Event.KeeperState.SyncConnected) {
				System.out.println("SyncConnected");
				synchronized (mutex) {
					mutex.notify();
				}
			}
			else if (event.getPath().equals(rootMembers)) {
				listMembers = zk.getChildren(rootMembers,  this, s);
				zk.getChildren(rootBarrier,  true, s);
				synchronized (mutexMember) {
					mutexMember.notify();
					leaderElection(listMembers);
				}
			}
			else if (event.getPath().equals(rootBarrier)) {
				listBarriers = zk.getChildren(rootBarrier, this, s);
				synchronized (mutexBarrier) {
					nBarriers ++;
					System.out.println("NBarriers: " + nBarriers);
					mutexBarrier.notify();
				}
			}
			System.out.println("-----------------------------------------------\n");
		} catch (Exception e) {
			System.out.println("Unexpected Exception process");
		}
	}

	private void leaderElection(List<String> list){
		//Barrier b = new Barrier(myId, "/b1", list.size());
		sizeBarrier = list.size();
		try{
			//zk.exists(rootMembers, false);
			//zk.exists(rootBarrier, this);
			zk.getChildren(rootMembers, false);
			zk.getChildren(rootBarrier, this);

			//boolean flag = b.enter();
			boolean flag = enter();
			System.out.println("Entered barrier: " + list.size());
			if(!flag) System.out.println("Error when entering the barrier");
		} catch (KeeperException e){
			System.out.println("Exception error: KeeperException leaderElection");
		} catch (InterruptedException e){
			System.out.println("Exception error: InterruptedException leaderElection");
		}

		// Generate random integer

		int r = rand.nextInt(100);
		// Loop for rand iterations
		for (int i = 0; i < r; i++) {
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {

			}
		}

		// Election
		Collections.sort(list);
		leader = list.get(0);
		if(leader.equals(myId)){
			System.out.println("****You are the leader****");
		} else {
			System.out.println("The process " + leader + " is the leader");
		}
		try{
			leave();
			//b.leave();
			//System.out.println("He borrado (en teoría)");
			System.out.println("Left barrier");
			zk.getChildren(rootBarrier, false);
			zk.getChildren(rootMembers, this);
//			zk.exists(rootBarrier, false);
//			zk.exists(rootMembers, this);
		} catch (KeeperException e){

		} catch (InterruptedException e){

		}
	}

	private void printListMembers (List<String> list) {
		//leaderElection(list);
		System.out.println("Remaining # members:" + list.size());
		System.out.print("The active members are: ");
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();
			if(leader.equals(string)){
				System.out.print("(L) " + string + ", ");
			}else {
				System.out.print(string + ", ");
			}
		}
		System.out.println();
		System.out.println("---------------------------------------------------");

	}

	public static void main(String[] args) {
		zkMember_aa2 zk = new zkMember_aa2();

		try {
			Thread.sleep(300000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}


	/**
	 * Barrier
	 */
//	static public class Barrier {
//		int size;
		String name;
		//String root;
		//String address;
		String nodoB;
		int nWatchers = 0;

		/**
		 * Barrier constructor
		 *
		 * @param address
		 * @param root
		 * @param size
		 */

		//public void createBarrier(String address, String root, int size)
		public void createBarrier() {
			//this.size = size; //args[2]
			//this.address = address;

			// Create barrier node
			if (zk != null) {
				try { //Crea /b1 si no existe
					Stat s = zk.exists(rootBarrier, false);
					if (s == null) {
						zk.create(rootBarrier, new byte[0], Ids.OPEN_ACL_UNSAFE,
								CreateMode.PERSISTENT);
					}
					//s = zk.exists(rootBarrier, this);
				} catch (KeeperException e) {
					System.out.println("Keeper exception when instantiating queue: "
							+ e.toString());
				} catch (InterruptedException e) {
					System.out.println("Interrupted exception");
				}
			}

			// My node name
			try {
				name = new String(InetAddress.getLocalHost().getCanonicalHostName().toString());
				System.out.println("****Name es: " +name);
			} catch (UnknownHostException e) {
				System.out.println(e.toString());
			}

		}

		private void printListBarriers (List<String> list) {
			System.out.println("Remaining # barrier:" + list.size());
			System.out.print("The active members are: ");
			for (Iterator iterator = list.iterator(); iterator.hasNext();) {
				String string = (String) iterator.next();
				System.out.print(string + ", ");
			}
			System.out.println();
			System.out.println("---------------------------------------------------");

		}

		/**
		 * Join barrier
		 *
		 * @return
		 * @throws KeeperException
		 * @throws InterruptedException
		 */

		boolean enter() throws KeeperException, InterruptedException{
			nodoB = zk.create(rootBarrier + "/" + name, new byte[0], Ids.OPEN_ACL_UNSAFE,
					CreateMode.EPHEMERAL_SEQUENTIAL);
			//s = zk.exists(rootBarrier, this);
			System.out.println("He creado el node " + name + "nodeB: " + nodoB);
			System.out.println("Estoy creando el znode de la operacion");
			while (true) {
				listBarriers = zk.getChildren(rootBarrier, this);
				printListBarriers(listBarriers);
				System.out.println("La lista de b1 tiene: " + listBarriers.size() + " y los members son " + sizeBarrier);

				if (listBarriers.size() < sizeBarrier) {
					System.out.println("Estas bloqueado");
					synchronized (mutexBarrier) {
						mutexBarrier.wait();
					}
				} else {
					return true;
				}
			}
		}



		/**
		 * Wait until all reach barrier
		 *
		 * @return
		 * @throws KeeperException
		 * @throws InterruptedException
		 */

		boolean leave() throws KeeperException, InterruptedException{

			try {
				Thread.sleep(5000);
			} catch (Exception e) {
			}
			// Borrar mejor name???
			zk.delete(nodoB, 0);
			System.out.println("He borrado el node" + name);
			while (true) {
				listBarriers = zk.getChildren(rootBarrier, this);
				if (listBarriers.size() > 0) {
					//lockBarrier.lock();
					synchronized (mutexBarrier) {
						mutexBarrier.wait();
					}
				} else {
					break;
				}
			}

			return true;
		}
	//}
}
