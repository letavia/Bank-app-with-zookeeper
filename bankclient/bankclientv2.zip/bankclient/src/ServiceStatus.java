
public class ServiceStatus {

}
