

import org.jgroups.Address;
//import zookeeper

public abstract interface SendMessages
{
  public abstract void sendAdd(Address paramAddress, Client paramClient);

  public abstract void sendRead(Address paramAddress, Integer paramInteger);

  public abstract void sendUpdate(Address paramAddress, Client paramClient);

  public abstract void sendDelete(Address paramAddress, Integer paramInteger);

  public abstract void sendCreateBank(Address paramAddress, ClientDB paramClientDB);
}
