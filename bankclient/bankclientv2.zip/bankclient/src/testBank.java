
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;


public class testBank implements Watcher {
	private static final int SESSION_TIMEOUT = 5000;
	private ZooKeeper zk;
	
	public static void main(String[] args) {
         Object cWatcher;
	//	ZooKeeper zk = new ZooKeeper(zkBankWatcher.server, n);
  
	}
	public void process(WatchedEvent event) {
		// TODO Auto-generated method stub
		
	}
}
