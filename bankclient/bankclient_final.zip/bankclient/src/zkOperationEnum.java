

import java.io.Serializable;

public enum zkOperationEnum
  implements Serializable
{
  CREATE_CLIENT,  READ_CLIENT,  UPDATE_CLIENT,  DELETE_CLIENT,  READ_CLIENT_DB;
}
