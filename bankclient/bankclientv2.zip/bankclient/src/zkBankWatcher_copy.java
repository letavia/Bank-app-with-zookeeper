

import java.util.Iterator;
import java.util.List;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Random;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;

public class zkBankWatcher_copy implements Watcher{
	private static final int SESSION_TIMEOUT = 5000;

	private static String rootMembers = "/members";
	private static String aMember = "/member-";
	private static String rootOperations = "/operations";
	private static String anOperation = "/op-";
	private String myId;

	// This is static. A list of zookeeper can be provided for decide where to connect
	String[] hosts = {"127.0.0.1:2181", "127.0.0.1:2182", "127.0.0.1:2183"};

	private ZooKeeper zk;

	public zkBankWatcher_copy () {

		// Select a random zookeeper server
		Random rand = new Random();
		int i = rand.nextInt(hosts.length);

		// Create a session and wait until it is created.
		// When is created, the watcher is notified
		try {
			if (zk == null) {
				zk = new ZooKeeper(hosts[i], SESSION_TIMEOUT, cWatcher);
				try {
					// Wait for creating the session. Use the object lock
					wait();
					//zk.exists("/",false);
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		} catch (Exception e) {
			System.out.println("Error");
		}

		// Add the process to the members in zookeeper

		if (zk != null) {
			// Create a folder for members and include this process/server
			try {
				// Create a folder, if it is not created
				//String response = new String();
				String rootMembersCreated; 
				String rootOperationsCreated;
				Stat rootMembersExist = zk.exists(rootMembers, watcherMember); //this);
				if (rootMembersExist == null) {
					// Created the znode, if it is not created.
					rootMembersCreated = zk.create(rootMembers, new byte[0],
							Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
					System.out.println("root members created: " + rootMembersCreated);
				}

				// Create a znode for registering as member and get my id
				myId = zk.create(rootMembers + aMember, new byte[0],
						Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);

				myId = myId.replace(rootMembers + "/", "");

				List<String> listMember = zk.getChildren(rootMembers, watcherMember, rootMembersExist); //this, s);
				System.out.println("Created znode member id:"+ myId );
				printListMembers(listMember);
				byte[] bn = zk.getData("/members/" + myId, false, null);
				String data;
				try {
					data = new String(bn, "UTF-8");
					System.out.println(data);
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	

				
				//create root operations folder
				Stat rootOperationsExist = zk.exists(rootOperations, watcherOperation); //this);
				if (rootOperationsExist == null) {
					// Created the znode, if it is not created.
					rootOperationsCreated = zk.create(rootOperations, new byte[0],
							Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
					System.out.println("root operations created: " + rootOperationsCreated);
				}
				
				List<String> listOperation = zk.getChildren(rootOperations, watcherOperation, rootOperationsExist); //this, s);
				printListOperations(listOperation);
				
			} catch (KeeperException e) {
				System.out.println("The session with Zookeeper failes. Closing");
				return;
			} catch (InterruptedException e) {
				System.out.println("InterruptedException raised");
			}

		}

	}

	private Watcher cWatcher = new Watcher() {
		public void process (WatchedEvent e) {
			System.out.println("Created session");
			System.out.println(e.toString());
			notify();
		}
	};

	private Watcher  watcherMember = new Watcher() {
		public void process(WatchedEvent event) {
			System.out.println("------------------Watcher Member------------------\n");
			try {
				System.out.println(" an Update!!");
				System.out.println("!!!!!!" + event.toString());
				
				List<String> list = zk.getChildren(rootMembers,  watcherMember); //this);
				printListMembers(list);
				byte[] bn = zk.getData("/members/" + myId, false, null);
				String data;

					data = new String(bn, "UTF-8");
					System.out.println(data);
		
				//byte[] getContent=zk.getData(aMember, watcherMember, null);
				//System.out.println(getContent.toString());
			} catch (Exception e) {
				System.out.println("Exception: wacherMember");
			}
		}
	};
	
	private Watcher  watcherOperation = new Watcher() {
		public void process(WatchedEvent event) {
			System.out.println("------------------Watcher Operation------------------\n");
			try {
				System.out.println(" an Update!!");
				System.out.println("!!!!!!" + event.toString());
				List<String> list = zk.getChildren(rootOperations,  watcherOperation); //this);
				printListOperations(list);
			} catch (Exception e) {
				System.out.println("Exception: wacherOperation");
			}
		}
	};

	public void process(WatchedEvent event) {
		try {
			//System.out.println("!!!!!!" + event.toString());
			//List<String> listMember = zk.getChildren(rootMembers, watcherMember); //this);
			//printListMembers(listMember);
			//byte[] getContent=zk.getData(, watcherOperation, null);
			//System.out.println(getContent.toString());
			List<String> listOperation = zk.getChildren(rootOperations, watcherOperation); //this);
			printListMembers(listOperation);
		} catch (Exception e) {
			System.out.println("Error in project");
		}


	}

	private void printListMembers (List<String> list) {
		System.out.println("Number of members:" + list.size());
		System.out.print("list of members: ");
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();
			System.out.print(string + ", ");
		}
		System.out.println();

	}
	
	private void printListOperations (List<String> list) {
		System.out.println("Number of Operations:" + list.size());
		System.out.print("List of Operations: ");
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();
			System.out.print(string + ", ");
		}
		System.out.println();

	}

	public static void main(String[] args) {
		zkBankWatcher_copy zk = new zkBankWatcher_copy();
        //System.out.print("dodol");
		try {
			Thread.sleep(300000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
